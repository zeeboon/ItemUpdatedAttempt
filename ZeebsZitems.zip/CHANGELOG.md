`1.1.4`
- Forgot to change readme so it doesn't say Stinky Bomb is disabled anymore -_- ffs I always forget something

`1.1.3`
- Enabled Stinky Bomb again (yay)
- Increased Stinky Bomb damage a little bit (170% + 100 -> 180% + 110%), it was balanced around Sticky Bomb but honestly Sticky Bomb kinda sucks

`1.1.2`
- Removed item spawn shortcuts v_v Sorry, you'll have to actually find the items normally now

`1.1.1`
- Fixed icons

`1.1.0`

- Updated to work with Seekers of the Storm
- Temporarily disabled Stinky Bomb because the SotS update broke DotAPI
- Lowered Champion Fungus heal from 12% to 10%
- Clarified how Death's Doorhandle works a little bit
- Split R2API dependencies into submodules

`1.0.1`

- Nevermind I lied.
- Fixed 100% Stinky Bomb proc chance <_< no one saw that

`1.0.0`

- Finished forever. :-)

